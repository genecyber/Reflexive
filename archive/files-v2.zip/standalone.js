/**
 * Example: Standalone usage - IT JUST WORKS
 * 
 * Just import and create. Dashboard auto-starts on :3099
 */

import { createReflexive } from '../src/index.js';

// That's it. Dashboard is now running at http://localhost:3099
const reflex = createReflexive();

// Expose some state the agent can see
let counter = 0;
reflex.expose('counter', () => counter);

// Log some things
reflex.log('Script started');

// Simulate some work
setInterval(() => {
  counter++;
  if (counter % 10 === 0) {
    reflex.log('Counter update', { counter });
  }
  if (counter % 25 === 0) {
    reflex.warn('Counter getting high', { counter });
  }
}, 1000);

// Simulate occasional errors
setInterval(() => {
  if (Math.random() < 0.1) {
    try {
      throw new Error('Random simulated error');
    } catch (e) {
      reflex.catch(e, { source: 'random-error-generator' });
    }
  }
}, 5000);

console.log(`
Script is running. The agent can see:
- The counter value (exposed state)
- All logs
- Any errors that occur

Open the dashboard to chat with it!
`);

// Keep the process alive
process.stdin.resume();
