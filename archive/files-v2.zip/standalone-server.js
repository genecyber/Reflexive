/**
 * Standalone Server - Auto-starts a dashboard server
 * 
 * For scripts and apps that don't have their own HTTP server,
 * this provides the reflexive dashboard automatically.
 */

import { createServer } from 'http';
import { parse } from 'url';

export class StandaloneServer {
  constructor(agent, options = {}) {
    this.agent = agent;
    this.options = options;
    this.port = options.port || 3099;
    this.host = options.host || 'localhost';
    this.server = null;
    this.isRunning = false;
  }

  async start() {
    if (this.isRunning) return this;

    return new Promise((resolve, reject) => {
      this.server = createServer((req, res) => this._handleRequest(req, res));

      this.server.on('error', (err) => {
        if (err.code === 'EADDRINUSE') {
          // Port in use - try next port
          this.port++;
          if (this.port < (this.options.port || 3099) + 10) {
            this.server.listen(this.port, this.host);
          } else {
            reject(new Error(`Could not find available port`));
          }
        } else {
          reject(err);
        }
      });

      this.server.on('listening', () => {
        this.isRunning = true;
        const url = `http://${this.host}:${this.port}`;
        
        if (this.options.silent !== true) {
          console.log(`\n⚡ Reflexive Dashboard: ${url}\n`);
        }

        // Auto-open browser if requested
        if (this.options.open) {
          this._openBrowser(url);
        }

        resolve(this);
      });

      this.server.listen(this.port, this.host);
    });
  }

  async stop() {
    if (!this.isRunning) return this;

    return new Promise((resolve) => {
      this.server.close(() => {
        this.isRunning = false;
        resolve(this);
      });
    });
  }

  async _handleRequest(req, res) {
    const { pathname } = parse(req.url, true);
    const query = parse(req.url, true).query;

    // CORS headers for local dev
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    try {
      // Route handling
      if (pathname === '/' || pathname === '/dashboard') {
        return this._serveDashboard(res);
      }

      if (pathname === '/chat' && req.method === 'POST') {
        return this._handleChat(req, res);
      }

      if (pathname === '/health') {
        return this._serveJSON(res, this._getHealth());
      }

      if (pathname === '/inspect') {
        return this._serveJSON(res, this.agent._introspector?.snapshot() || {});
      }

      if (pathname === '/logs') {
        const logs = this.agent._options?.logger?.query({
          level: query.level,
          search: query.search,
          limit: query.limit ? parseInt(query.limit) : 50
        }) || [];
        return this._serveJSON(res, logs);
      }

      if (pathname === '/errors') {
        const errors = this.agent._options?.errorCapture?.getRecent(
          query.count ? parseInt(query.count) : 20
        ) || [];
        return this._serveJSON(res, errors);
      }

      if (pathname === '/state') {
        return this._serveJSON(res, this.agent._options?.stateRegistry?.getAll() || {});
      }

      if (pathname === '/channels') {
        return this._serveJSON(res, this.agent._options?.channels?.list() || []);
      }

      if (pathname === '/files') {
        return this._serveJSON(res, this.agent._introspector?.getCodeStructure() || {});
      }

      // 404
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Not found' }));

    } catch (error) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: error.message }));
    }
  }

  async _handleChat(req, res) {
    let body = '';
    for await (const chunk of req) {
      body += chunk;
    }

    try {
      const { message, sessionId } = JSON.parse(body);

      if (!message) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'message required' }));
        return;
      }

      const result = await this.agent.chat(message, { sessionId });
      this._serveJSON(res, result);

    } catch (error) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: error.message }));
    }
  }

  _getHealth() {
    const introspector = this.agent._introspector;
    const state = introspector?.getProcessState() || {};
    const eventLoop = introspector?.getEventLoopState() || {};

    return {
      status: 'healthy',
      uptime: state.uptime,
      memory: state.memory,
      eventLoop,
      timestamp: new Date().toISOString()
    };
  }

  _serveJSON(res, data) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(data, null, 2));
  }

  _serveDashboard(res) {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(getDashboardHTML());
  }

  _openBrowser(url) {
    const { platform } = process;
    const cmd = platform === 'darwin' ? 'open' :
                platform === 'win32' ? 'start' : 'xdg-open';

    import('child_process').then(({ exec }) => {
      exec(`${cmd} ${url}`);
    }).catch(() => {
      // Silently fail if we can't open browser
    });
  }
}

function getDashboardHTML() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>⚡ Reflexive</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #0a0a0f;
      color: #e0e0e0;
      min-height: 100vh;
    }
    .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px 0;
      border-bottom: 1px solid #222;
      margin-bottom: 20px;
    }
    h1 { font-size: 1.25rem; color: #fff; display: flex; align-items: center; gap: 8px; }
    .status { display: flex; gap: 16px; font-size: 0.8rem; color: #888; }
    .status-item { display: flex; align-items: center; gap: 6px; }
    .dot { width: 8px; height: 8px; border-radius: 50%; background: #22c55e; }
    
    .grid { display: grid; grid-template-columns: 1fr 300px; gap: 20px; height: calc(100vh - 120px); }
    @media (max-width: 800px) { .grid { grid-template-columns: 1fr; } }
    
    .chat-panel {
      background: #111118;
      border: 1px solid #222;
      border-radius: 8px;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }
    .chat-header {
      padding: 12px 16px;
      background: #16161d;
      border-bottom: 1px solid #222;
      font-weight: 500;
      font-size: 0.875rem;
    }
    .chat-messages {
      flex: 1;
      overflow-y: auto;
      padding: 16px;
    }
    .message { margin-bottom: 16px; }
    .message.user .bubble { background: #1e3a5f; margin-left: 40px; }
    .message.assistant .bubble { background: #1a1a24; margin-right: 40px; }
    .bubble {
      padding: 12px 16px;
      border-radius: 12px;
      font-size: 0.9rem;
      line-height: 1.5;
      white-space: pre-wrap;
    }
    .message-meta { font-size: 0.7rem; color: #666; margin-bottom: 4px; padding: 0 4px; }
    .chat-input-area {
      padding: 16px;
      border-top: 1px solid #222;
      background: #0d0d12;
    }
    .chat-input-wrapper { display: flex; gap: 8px; }
    .chat-input {
      flex: 1;
      padding: 12px 16px;
      background: #16161d;
      border: 1px solid #333;
      border-radius: 8px;
      color: #fff;
      font-size: 0.9rem;
      resize: none;
      font-family: inherit;
    }
    .chat-input:focus { outline: none; border-color: #3b82f6; }
    .chat-send {
      padding: 12px 24px;
      background: #3b82f6;
      border: none;
      border-radius: 8px;
      color: #fff;
      cursor: pointer;
      font-weight: 500;
      transition: background 0.2s;
    }
    .chat-send:hover { background: #2563eb; }
    .chat-send:disabled { opacity: 0.5; cursor: not-allowed; }
    
    .sidebar { display: flex; flex-direction: column; gap: 16px; }
    .panel {
      background: #111118;
      border: 1px solid #222;
      border-radius: 8px;
      overflow: hidden;
    }
    .panel-header {
      padding: 10px 14px;
      background: #16161d;
      border-bottom: 1px solid #222;
      font-weight: 500;
      font-size: 0.8rem;
      color: #999;
    }
    .panel-body { padding: 14px; font-size: 0.85rem; }
    
    .metrics { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .metric { text-align: center; }
    .metric-value { font-size: 1.5rem; font-weight: 600; color: #fff; }
    .metric-label { font-size: 0.7rem; color: #666; margin-top: 2px; }
    
    .logs { font-family: 'SF Mono', Monaco, monospace; font-size: 0.7rem; max-height: 150px; overflow-y: auto; }
    .log-entry { padding: 3px 0; border-bottom: 1px solid #1a1a22; display: flex; gap: 8px; }
    .log-level { width: 40px; flex-shrink: 0; }
    .log-entry.error .log-level { color: #ef4444; }
    .log-entry.warn .log-level { color: #eab308; }
    .log-entry.info .log-level { color: #3b82f6; }
    .log-entry.debug .log-level { color: #666; }
    .log-message { color: #999; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    
    .thinking { display: flex; gap: 4px; padding: 8px 0; }
    .thinking span {
      width: 8px; height: 8px; background: #3b82f6; border-radius: 50%;
      animation: bounce 1.4s infinite ease-in-out;
    }
    .thinking span:nth-child(1) { animation-delay: -0.32s; }
    .thinking span:nth-child(2) { animation-delay: -0.16s; }
    @keyframes bounce {
      0%, 80%, 100% { transform: scale(0); }
      40% { transform: scale(1); }
    }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <h1>⚡ Reflexive</h1>
      <div class="status">
        <div class="status-item"><span class="dot"></span><span id="uptime">--</span></div>
        <div class="status-item"><span id="memory">--</span> MB</div>
      </div>
    </header>
    
    <div class="grid">
      <div class="chat-panel">
        <div class="chat-header">Chat with your app</div>
        <div class="chat-messages" id="messages"></div>
        <div class="chat-input-area">
          <div class="chat-input-wrapper">
            <textarea class="chat-input" id="input" rows="1" placeholder="Ask about your app..."></textarea>
            <button class="chat-send" id="send">Send</button>
          </div>
        </div>
      </div>
      
      <div class="sidebar">
        <div class="panel">
          <div class="panel-header">METRICS</div>
          <div class="panel-body">
            <div class="metrics">
              <div class="metric">
                <div class="metric-value" id="m-requests">--</div>
                <div class="metric-label">Requests</div>
              </div>
              <div class="metric">
                <div class="metric-value" id="m-errors">--</div>
                <div class="metric-label">Errors</div>
              </div>
              <div class="metric">
                <div class="metric-value" id="m-handles">--</div>
                <div class="metric-label">Handles</div>
              </div>
              <div class="metric">
                <div class="metric-value" id="m-logs">--</div>
                <div class="metric-label">Logs</div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="panel" style="flex: 1; display: flex; flex-direction: column;">
          <div class="panel-header">RECENT LOGS</div>
          <div class="panel-body" style="flex: 1; overflow: hidden;">
            <div class="logs" id="logs"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <script>
    const messagesEl = document.getElementById('messages');
    const inputEl = document.getElementById('input');
    const sendBtn = document.getElementById('send');
    let isLoading = false;

    function addMessage(role, text) {
      const div = document.createElement('div');
      div.className = 'message ' + role;
      div.innerHTML = '<div class="message-meta">' + role + '</div><div class="bubble">' + escapeHtml(text) + '</div>';
      messagesEl.appendChild(div);
      messagesEl.scrollTop = messagesEl.scrollHeight;
    }

    function escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }

    function showThinking() {
      const div = document.createElement('div');
      div.className = 'message assistant';
      div.id = 'thinking';
      div.innerHTML = '<div class="message-meta">assistant</div><div class="thinking"><span></span><span></span><span></span></div>';
      messagesEl.appendChild(div);
      messagesEl.scrollTop = messagesEl.scrollHeight;
    }

    function hideThinking() {
      document.getElementById('thinking')?.remove();
    }

    async function sendMessage() {
      const message = inputEl.value.trim();
      if (!message || isLoading) return;

      inputEl.value = '';
      isLoading = true;
      sendBtn.disabled = true;
      addMessage('user', message);
      showThinking();

      try {
        const res = await fetch('/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message })
        });
        const data = await res.json();
        hideThinking();
        addMessage('assistant', data.text || data.error || 'No response');
      } catch (e) {
        hideThinking();
        addMessage('assistant', 'Error: ' + e.message);
      }

      isLoading = false;
      sendBtn.disabled = false;
      inputEl.focus();
    }

    sendBtn.onclick = sendMessage;
    inputEl.onkeydown = (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    };

    // Auto-resize textarea
    inputEl.oninput = () => {
      inputEl.style.height = 'auto';
      inputEl.style.height = Math.min(inputEl.scrollHeight, 120) + 'px';
    };

    async function refresh() {
      try {
        const [health, inspect, logs] = await Promise.all([
          fetch('/health').then(r => r.json()),
          fetch('/inspect').then(r => r.json()),
          fetch('/logs?limit=10').then(r => r.json())
        ]);

        document.getElementById('uptime').textContent = Math.floor(health.uptime || 0) + 's';
        document.getElementById('memory').textContent = health.memory?.heapUsedMB || '--';
        document.getElementById('m-handles').textContent = health.eventLoop?.activeHandles || 0;
        document.getElementById('m-requests').textContent = inspect.recentRequests?.length || 0;
        document.getElementById('m-errors').textContent = inspect.errors?.length || 0;
        document.getElementById('m-logs').textContent = logs.length;

        const logsEl = document.getElementById('logs');
        logsEl.innerHTML = logs.map(l => 
          '<div class="log-entry ' + l.level + '">' +
          '<span class="log-level">' + l.level + '</span>' +
          '<span class="log-message">' + escapeHtml(l.message) + '</span>' +
          '</div>'
        ).join('');
      } catch (e) {}
    }

    refresh();
    setInterval(refresh, 3000);
    inputEl.focus();
  </script>
</body>
</html>`;
}

export { getDashboardHTML };
