/**
 * Reflexive - Make your application self-aware
 * 
 * The agent doesn't just talk to your app, it lives inside it.
 */

import { Introspector } from './introspector.js';
import { Transport } from './transports/index.js';
import { createRouter } from './router.js';
import { Logger } from './logger.js';
import { ErrorCapture } from './error-capture.js';
import { StateRegistry } from './state-registry.js';
import { ChannelBus } from './channels.js';
import { AgentCore } from './agent.js';
import { StandaloneServer } from './standalone-server.js';

export function createReflexive(config = {}) {
  const options = {
    root: config.root || process.cwd(),
    name: config.name || 'reflexive',
    
    // Capabilities - explicit opt-in for dangerous stuff
    capabilities: {
      readFiles: config.capabilities?.readFiles ?? true,
      writeFiles: config.capabilities?.writeFiles ?? false,
      executeCode: config.capabilities?.executeCode ?? false,
      modifySelf: config.capabilities?.modifySelf ?? false,
      networkAccess: config.capabilities?.networkAccess ?? false,
      shellAccess: config.capabilities?.shellAccess ?? false,
      bypassPermissions: config.capabilities?.bypassPermissions ?? false,
      ...config.capabilities
    },
    
    // File boundaries
    boundaries: {
      canRead: config.boundaries?.canRead || ['**/*'],
      canWrite: config.boundaries?.canWrite || [],
      ignore: config.boundaries?.ignore || ['node_modules/**', '.git/**', '.env*']
    },
    
    // Transport defaults to in-memory event emitter
    transport: config.transport || 'memory',
    
    // API config
    apiKey: config.apiKey || process.env.ANTHROPIC_API_KEY,
    model: config.model || 'sonnet',
    
    // Server config - AUTO-START BY DEFAULT
    server: {
      enabled: config.server?.enabled ?? true,
      port: config.server?.port ?? 3099,
      host: config.server?.host ?? 'localhost',
      open: config.server?.open ?? false,
      silent: config.server?.silent ?? false,
      ...config.server
    },
    
    ...config
  };

  // Core systems
  const introspector = new Introspector(options);
  const transport = Transport.create(options.transport, options);
  const logger = new Logger(options);
  const errorCapture = new ErrorCapture(options);
  const stateRegistry = new StateRegistry(options);
  const channels = new ChannelBus(transport);
  
  // The agent itself
  const agent = new AgentCore({
    ...options,
    introspector,
    logger,
    errorCapture,
    stateRegistry,
    channels
  });

  // Standalone server (auto-starts if enabled)
  let standaloneServer = null;

  // The public API
  const reflexive = {
    // Identity
    name: options.name,
    
    // ============ LOGGING ============
    // Structured logging the agent can query
    log: (message, data, meta) => logger.log('info', message, data, meta),
    debug: (message, data, meta) => logger.log('debug', message, data, meta),
    warn: (message, data, meta) => logger.log('warn', message, data, meta),
    error: (message, data, meta) => logger.log('error', message, data, meta),
    
    // ============ STATE EXPOSURE ============
    // Expose internal state to the agent
    expose: (name, valueOrGetter, meta) => stateRegistry.expose(name, valueOrGetter, meta),
    unexpose: (name) => stateRegistry.unexpose(name),
    
    // ============ CHANNELS ============
    // Event pub/sub the agent can participate in
    channel: (name) => channels.get(name),
    
    // ============ MARKERS ============
    // Annotate your code for the agent
    flag: (type, message, location) => introspector.addFlag(type, message, location),
    mark: (name, data) => introspector.mark(name, data),
    
    // ============ MIDDLEWARE ============
    // Framework-agnostic request tracing
    middleware: () => introspector.createMiddleware(),
    
    // ============ ERROR HANDLING ============
    // Wrap functions with intelligent error capture
    wrap: (fn, context) => errorCapture.wrap(fn, context),
    catch: (error, context) => errorCapture.capture(error, context),
    
    // Global error handling
    attachGlobalErrorHandlers: () => errorCapture.attachGlobal(),
    
    // ============ CHAT ============
    // Direct interaction
    chat: (message, chatOptions) => agent.chat(message, chatOptions),
    
    // ============ FRAMEWORK INTEGRATION ============
    // Get router for mounting (disables standalone server)
    router: (framework) => {
      // If using router(), disable standalone server
      if (standaloneServer) {
        standaloneServer.stop();
        standaloneServer = null;
      }
      return createRouter(agent, framework, options);
    },
    
    // ============ INTROSPECTION ============
    // Direct access to internals (for advanced use)
    inspect: () => introspector.snapshot(),
    
    // ============ LIFECYCLE ============
    start: async () => {
      await agent.start();
      if (options.server.enabled && !standaloneServer) {
        standaloneServer = new StandaloneServer(agent, options.server);
        await standaloneServer.start();
      }
      return reflexive;
    },
    stop: async () => {
      await agent.stop();
      if (standaloneServer) {
        await standaloneServer.stop();
        standaloneServer = null;
      }
      return reflexive;
    },
    
    // ============ SERVER CONTROL ============
    // Manual server control
    get server() {
      return standaloneServer;
    },
    get serverUrl() {
      return standaloneServer?.isRunning 
        ? `http://${standaloneServer.host}:${standaloneServer.port}`
        : null;
    },
    
    // ============ INTERNALS (for framework adapters) ============
    _agent: agent,
    _introspector: introspector,
    _transport: transport,
    _options: options
  };

  // Auto-attach error handlers if not disabled
  if (options.autoAttachErrors !== false) {
    errorCapture.attachGlobal();
  }

  // AUTO-START server if enabled
  if (options.server.enabled) {
    standaloneServer = new StandaloneServer(agent, options.server);
    standaloneServer.start().catch(err => {
      if (!options.server.silent) {
        console.error('⚡ Reflexive server failed to start:', err.message);
      }
    });
  }

  return reflexive;
}

// Re-exports
export { Transport } from './transports/index.js';
export { Introspector } from './introspector.js';
export { StandaloneServer } from './standalone-server.js';

// Default instance for quick usage
let defaultInstance = null;
export function getDefault() {
  if (!defaultInstance) {
    defaultInstance = createReflexive();
  }
  return defaultInstance;
}
