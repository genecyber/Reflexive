/**
 * AgentCore - Using @anthropic-ai/claude-agent-sdk
 * 
 * This leverages the actual Claude Agent SDK that powers Claude Code,
 * giving us built-in file operations, code execution, and the
 * full agentic loop - rather than reinventing it.
 * 
 * Key concepts:
 * - query() returns an async generator that streams SDKMessage objects
 * - Custom tools via MCP servers using createSdkMcpServer() and tool()
 * - Built-in tools: Read, Write, Edit, Bash, Glob, Grep, WebSearch, WebFetch
 */

import { query, tool, createSdkMcpServer } from '@anthropic-ai/claude-agent-sdk';
import { z } from 'zod';

export class AgentCore {
  constructor(options) {
    this.options = options;
    
    // Internal systems (for context injection)
    this.introspector = options.introspector;
    this.logger = options.logger;
    this.errorCapture = options.errorCapture;
    this.stateRegistry = options.stateRegistry;
    this.channels = options.channels;
    
    // Wire up dependencies
    if (this.logger) this.logger.setIntrospector(this.introspector);
    if (this.errorCapture) {
      this.errorCapture.setDependencies({
        introspector: this.introspector,
        stateRegistry: this.stateRegistry,
        logger: this.logger,
        agent: this
      });
    }
    
    // Create MCP server with our custom introspection tools
    this.mcpServer = this._createMcpServer();
    
    // Session tracking for multi-turn conversations
    this.sessions = new Map();
  }

  /**
   * Create an MCP server with our custom introspection tools
   */
  _createMcpServer() {
    const self = this;
    
    return createSdkMcpServer({
      name: 'reflexive-introspection',
      tools: [
        // Process state tool
        tool(
          'get_process_state',
          'Get current process state: memory, CPU, uptime, active handles, event loop info',
          {},
          async () => ({
            content: [{
              type: 'text',
              text: JSON.stringify(self.introspector?.getProcessState() || {}, null, 2)
            }]
          })
        ),
        
        // Exposed application state
        tool(
          'get_exposed_state',
          'Get all application state the developer has explicitly exposed via reflex.expose()',
          {},
          async () => ({
            content: [{
              type: 'text',
              text: JSON.stringify(self.stateRegistry?.getAll() || {}, null, 2)
            }]
          })
        ),
        
        // Query logs
        tool(
          'query_logs',
          'Query application logs with filters for level, search text, time range, and request ID',
          {
            level: z.string().optional().describe('Filter by level: debug, info, warn, error'),
            search: z.string().optional().describe('Search in message and data'),
            limit: z.number().optional().describe('Max results to return (default 50)'),
            since: z.string().optional().describe('ISO timestamp to filter from'),
            requestId: z.string().optional().describe('Filter by HTTP request ID')
          },
          async (params) => ({
            content: [{
              type: 'text',
              text: JSON.stringify(self.logger?.query(params) || [], null, 2)
            }]
          })
        ),
        
        // Recent errors with full context
        tool(
          'get_recent_errors',
          'Get recently captured errors with full context including stack traces, source code snippets, and application state at time of error',
          {
            count: z.number().optional().describe('Number of errors to return (default 10)')
          },
          async ({ count }) => ({
            content: [{
              type: 'text',
              text: JSON.stringify(self.errorCapture?.getRecent(count || 10) || [], null, 2)
            }]
          })
        ),
        
        // Specific error details
        tool(
          'get_error_details',
          'Get detailed information about a specific captured error by its ID',
          {
            errorId: z.string().describe('The error ID (e.g., err_1234567890_abc123)')
          },
          async ({ errorId }) => {
            const error = self.errorCapture?.get(errorId);
            return {
              content: [{
                type: 'text',
                text: error 
                  ? JSON.stringify(error, null, 2)
                  : `Error not found: ${errorId}`
              }]
            };
          }
        ),
        
        // Recent HTTP requests
        tool(
          'get_recent_requests',
          'Get recent HTTP requests that have been tracked through the application middleware',
          {
            count: z.number().optional().describe('Number of requests to return (default 20)')
          },
          async ({ count }) => ({
            content: [{
              type: 'text',
              text: JSON.stringify(self.introspector?.getRecentRequests(count || 20) || [], null, 2)
            }]
          })
        ),
        
        // Current request context
        tool(
          'get_current_request',
          'Get the current HTTP request context if this chat is happening within a request handler',
          {},
          async () => ({
            content: [{
              type: 'text',
              text: JSON.stringify(self.introspector?.getCurrentContext() || null, null, 2)
            }]
          })
        ),
        
        // Emit event to channel
        tool(
          'emit_event',
          'Emit an event to a named channel for other parts of the application to receive',
          {
            channel: z.string().describe('Channel name'),
            data: z.record(z.unknown()).describe('Event payload as JSON object')
          },
          async ({ channel, data }) => {
            self.channels?.channel(channel).emit(data);
            return {
              content: [{
                type: 'text',
                text: `Event emitted to channel "${channel}"`
              }]
            };
          }
        ),
        
        // Get channel event history
        tool(
          'get_channel_history',
          'Get recent events from a specific channel',
          {
            channel: z.string().describe('Channel name'),
            limit: z.number().optional().describe('Max events to return (default 20)')
          },
          async ({ channel, limit }) => ({
            content: [{
              type: 'text',
              text: JSON.stringify(
                self.channels?.getHistory({ channel, limit: limit || 20 }) || [],
                null, 2
              )
            }]
          })
        ),
        
        // List all channels
        tool(
          'list_channels',
          'List all active event channels and their subscriber counts',
          {},
          async () => ({
            content: [{
              type: 'text',
              text: JSON.stringify(self.channels?.list() || [], null, 2)
            }]
          })
        ),
        
        // Get full introspection snapshot
        tool(
          'get_full_snapshot',
          'Get a complete snapshot of the application state including process info, requests, errors, logs, and exposed state',
          {},
          async () => ({
            content: [{
              type: 'text',
              text: JSON.stringify(self.introspector?.snapshot() || {}, null, 2)
            }]
          })
        )
      ]
    });
  }

  /**
   * Build the allowed tools list based on capabilities
   */
  _getAllowedTools() {
    const caps = this.options.capabilities;
    const tools = [];
    
    // Built-in SDK tools based on capabilities
    if (caps.readFiles) {
      tools.push('Read', 'Glob', 'Grep');
    }
    if (caps.writeFiles) {
      tools.push('Write', 'Edit', 'MultiEdit');
    }
    if (caps.shellAccess) {
      tools.push('Bash');
    }
    if (caps.networkAccess) {
      tools.push('WebSearch', 'WebFetch');
    }
    
    return tools;
  }

  /**
   * Build the system prompt with live context
   */
  _buildSystemPrompt() {
    const caps = this.options.capabilities;
    const processState = this.introspector?.getProcessState();
    const exposedState = this.stateRegistry?.list() || [];
    const recentErrors = this.errorCapture?.getRecent(3) || [];
    const logStats = this.logger?.getStats();
    
    const lines = [
      '# Reflexive Agent',
      '',
      'You are an AI assistant embedded inside a running Node.js application. You have deep visibility into the process state, code structure, logs, and any state the developer has exposed to you.',
      '',
      '## Your Capabilities',
      `- Read files: ${caps.readFiles ? 'YES' : 'NO'}`,
      `- Write/Edit files: ${caps.writeFiles ? 'YES' : 'NO'}`,
      `- Run shell commands: ${caps.shellAccess ? 'YES' : 'NO'}`,
      `- Web search/fetch: ${caps.networkAccess ? 'YES' : 'NO'}`,
      '',
      '## Custom Introspection Tools',
      'In addition to standard file/shell tools, you have access to:',
      '- `get_process_state` - Live process metrics (memory, CPU, uptime)',
      '- `get_exposed_state` - Application state the developer exposed',
      '- `query_logs` - Search and filter application logs',
      '- `get_recent_errors` - Errors with stack traces and context',
      '- `get_error_details` - Deep dive into a specific error',
      '- `get_recent_requests` - HTTP request history',
      '- `get_current_request` - Current request context',
      '- `emit_event` / `get_channel_history` / `list_channels` - Event pub/sub',
      '- `get_full_snapshot` - Complete application state snapshot',
      '',
      '## Live Process State',
      `- PID: ${processState?.pid || '?'}`,
      `- Uptime: ${Math.round(processState?.uptime || 0)}s`,
      `- Memory: ${processState?.memory?.heapUsedMB || '?'}MB heap, ${processState?.memory?.rssMB || '?'}MB RSS`,
      ''
    ];
    
    if (exposedState.length > 0) {
      lines.push('## Exposed Application State');
      lines.push('The developer has exposed these values for you to query:');
      for (const item of exposedState.slice(0, 10)) {
        const desc = item.meta.description ? ` - ${item.meta.description}` : '';
        lines.push(`- \`${item.name}\`${desc}`);
      }
      if (exposedState.length > 10) {
        lines.push(`- ...and ${exposedState.length - 10} more`);
      }
      lines.push('');
    }
    
    if (logStats) {
      lines.push('## Log Summary');
      lines.push(`- ${logStats.total} total logs stored`);
      lines.push(`- ${logStats.lastHour} in the last hour`);
      if (logStats.byLevel.error > 0) {
        lines.push(`- ⚠️ ${logStats.byLevel.error} errors logged`);
      }
      lines.push('');
    }
    
    if (recentErrors.length > 0) {
      lines.push('## Recent Errors (use get_error_details for more info)');
      for (const err of recentErrors) {
        lines.push(`- **${err.name}**: ${err.message} (ID: ${err.id})`);
      }
      lines.push('');
    }
    
    lines.push('## Guidelines');
    lines.push('1. Use introspection tools to gather information before answering');
    lines.push('2. When debugging errors, read the relevant source files');
    lines.push('3. Be specific about file paths and line numbers');
    lines.push('4. If asked to make changes, explain what you\'ll do first');
    lines.push('5. The developer trusts you - be direct and helpful');
    lines.push('');
    lines.push(`## Working Directory: ${this.options.root}`);
    
    return lines.join('\n');
  }

  /**
   * Get permission mode based on capabilities
   */
  _getPermissionMode() {
    if (this.options.capabilities.bypassPermissions) {
      return 'bypassPermissions';
    }
    if (this.options.capabilities.writeFiles) {
      return 'acceptEdits';
    }
    return 'default';
  }

  /**
   * Chat with the agent
   */
  async chat(message, options = {}) {
    const sessionId = options.sessionId || 'default';
    
    // Build fresh context for this message
    const contextSummary = this._buildContextSummary();
    
    // Enrich message with live context
    const enrichedPrompt = `<live_application_context>
${contextSummary}
</live_application_context>

${message}`;

    // Build query options
    const queryOptions = {
      model: this.options.model || 'sonnet',
      cwd: this.options.root,
      allowedTools: this._getAllowedTools(),
      permissionMode: this._getPermissionMode(),
      maxTurns: options.maxTurns || 50,
      
      // Include our MCP server with introspection tools
      mcpServers: {
        'reflexive': this.mcpServer
      },
      
      // Custom system prompt with live state
      systemPrompt: this._buildSystemPrompt()
    };

    // If bypassPermissions, need to explicitly allow it
    if (queryOptions.permissionMode === 'bypassPermissions') {
      queryOptions.dangerouslySkipPermissions = true;
    }

    try {
      let textResponse = '';
      const toolResults = [];
      let resultMessage = null;
      
      // Stream through the query responses
      for await (const msg of query({ prompt: enrichedPrompt, options: queryOptions })) {
        // Collect assistant text
        if (msg.type === 'assistant') {
          for (const block of msg.message.content) {
            if (block.type === 'text') {
              textResponse += block.text;
            }
            if (block.type === 'tool_use') {
              toolResults.push({
                tool: block.name,
                input: block.input
              });
            }
          }
        }
        
        // Capture final result
        if (msg.type === 'result') {
          resultMessage = msg;
        }
      }
      
      // Log the interaction
      this.logger?.debug('Agent chat completed', {
        sessionId,
        messageLength: message.length,
        responseLength: textResponse.length,
        toolsUsed: toolResults.length
      });
      
      return {
        text: textResponse,
        toolResults,
        result: resultMessage?.result || null,
        subtype: resultMessage?.subtype || null
      };
      
    } catch (error) {
      this.logger?.error('Agent chat failed', { error: error.message });
      throw error;
    }
  }

  /**
   * Build a compact context summary for the prompt
   */
  _buildContextSummary() {
    const process = this.introspector?.getProcessState();
    const recentRequests = this.introspector?.getRecentRequests(5) || [];
    const recentErrors = this.errorCapture?.getRecent(3) || [];
    const currentRequest = this.introspector?.getCurrentContext();
    
    const lines = [
      `Process: PID ${process?.pid}, uptime ${Math.round(process?.uptime || 0)}s, ${process?.memory?.heapUsedMB || '?'}MB heap`
    ];
    
    if (currentRequest) {
      lines.push(`Current request: ${currentRequest.method} ${currentRequest.path}`);
    }
    
    if (recentRequests.length > 0) {
      lines.push(`Recent requests: ${recentRequests.map(r => `${r.method} ${r.path} (${r.statusCode || 'pending'})`).join(', ')}`);
    }
    
    if (recentErrors.length > 0) {
      lines.push(`Recent errors: ${recentErrors.map(e => `${e.name}: ${e.message}`).join('; ')}`);
    }
    
    return lines.join('\n');
  }

  /**
   * Stream chat responses (for real-time UI updates)
   */
  async *chatStream(message, options = {}) {
    const contextSummary = this._buildContextSummary();
    
    const enrichedPrompt = `<live_application_context>
${contextSummary}
</live_application_context>

${message}`;

    const queryOptions = {
      model: this.options.model || 'sonnet',
      cwd: this.options.root,
      allowedTools: this._getAllowedTools(),
      permissionMode: this._getPermissionMode(),
      maxTurns: options.maxTurns || 50,
      mcpServers: { 'reflexive': this.mcpServer },
      systemPrompt: this._buildSystemPrompt()
    };

    if (queryOptions.permissionMode === 'bypassPermissions') {
      queryOptions.dangerouslySkipPermissions = true;
    }

    for await (const msg of query({ prompt: enrichedPrompt, options: queryOptions })) {
      yield msg;
    }
  }

  /**
   * Clear conversation (note: SDK doesn't maintain state between queries by default)
   */
  clearConversation(sessionId = 'default') {
    this.sessions.delete(sessionId);
  }

  /**
   * Start the agent (no-op for now, could initialize background tasks)
   */
  async start() {
    return this;
  }

  /**
   * Stop the agent
   */
  async stop() {
    return this;
  }
}
